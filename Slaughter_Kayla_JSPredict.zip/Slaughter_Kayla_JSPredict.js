 Predict 
 console.log("I was born in" + 1980); // I was born in 1980

Predict
var birthYearInput = 1980
consloe.log("I was born in" + birthYearInput); // I was born in 1980

Predict
var num1 = 10;
var num2 = 20;
console.log (num1 + num2); // 30